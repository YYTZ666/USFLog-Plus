const readline = require('readline');
const fs = require("fs");
const process = require("process");
const http = require('http');
const https = require('https');
const path = require('path');
const zlib = require('zlib');

// Configuration
const defaultConfig = {
    port: 31145,
    chatApiPort: 31146,
    openIP: "0.0.0.0",
    chatApiIP: "0.0.0.0",
    maxConnectionsPerIP: 10,
    showConnectionInfo: true,
    useWhitelist: true,
    whitelist: ["127.0.0.1"],
    antiSpamEnable: true,
    showChatInConsole: true,
    debugMode: false,
    logBufferSize: 5 * 1024,
    logCleanupInterval: 86400000,
    logRetentionDays: 7,
    logCompression: true,
    chatApiEnabled: true,
    chatApiUrl: "http://example.com",
    pushPrivateChat: false,
    apiSecret: "114511",
    version: "1.0.8",
    detailedContainerLogs: true,
    lastStartupTime: "",
    lastStartupUser: "",
    largeJsonSupport: true
};

let config;
const configPath = './LogServer.json';

// Load or create config file
try {
    config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    config = {...defaultConfig, ...config};
} catch (err) {
    config = {...defaultConfig};
}
fs.writeFileSync(configPath, JSON.stringify(config, null, 2));


// Cumulative Statistics
let cumulativeStats = {
    date: get_date(),
    actions: {
        connection: 0,
        dimension: 0,
        interact: 0,
        chest: 0,
        kill: 0,
        death: 0,
        break: 0,
        place: 0,
        location: 0,
        gamemode: 0,
        sign: 0,
        chat: 0,
        unknown: 0
    },
    playerCount: 0,
    players: new Set()
};

// Load cumulative stats from file
function loadCumulativeStats() {
    const cumuPath = './Log/Cumu.log';
    try {
        const data = fs.readFileSync(cumuPath, 'utf-8');
        const stats = JSON.parse(data);
        stats.players = new Set(stats.players);
        cumulativeStats = stats;
    } catch (err) {
        console.error("Error loading cumulative stats:", err);
        saveCumulativeStats();
    }
}

// Save cumulative stats to file
function saveCumulativeStats() {
    const cumuPath = './Log/Cumu.log';
    ensureDir(path.dirname(cumuPath));
    fs.writeFileSync(cumuPath, JSON.stringify({...cumulativeStats, players: Array.from(cumulativeStats.players)}, null, 2));
}

// Update cumulative stats
function updateCumulativeStats(logType, playerName = null) {
    if (playerName && !cumulativeStats.players.has(playerName)) {
        const playerDir = `./Log/${get_date()}/players/${playerName}`;
        if (fs.existsSync(playerDir)) {
            cumulativeStats.players.add(playerName);
            cumulativeStats.playerCount = cumulativeStats.players.size;
            if (config.debugMode) {
                console.log('\x1b[36m%s\x1b[0m', `新增玩家统计: ${playerName}, 当前总数: ${cumulativeStats.playerCount}`);
            }
        }
    }
    cumulativeStats.actions[logType]++;
    saveCumulativeStats();
}


// Time functions
function get_time() {
    const date = new Date();
    return `[${padZero(date.getMonth() + 1)}.${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}:${padZero(date.getSeconds())}]`;
}

function padZero(num) {
    return num < 10 ? `0${num}` : num;
}

function get_shanghai_time() {
    const date = new Date();
    return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }).replace(/T/, ' ').slice(0, 19);
}

function get_utc_time() {
    const date = new Date();
    return date.toISOString().replace('T', ' ').slice(0, 19);
}

function get_date() {
    const date = new Date();
    return `${date.getFullYear()}.${padZero(date.getMonth() + 1)}.${padZero(date.getDate())}`;
}

// Directory handling
function ensureDir(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
}

// Log functions (using JSON format)
function log(text) {
    console.log(`${get_shanghai_time()} ${text}`);
}

function createLogJson(type, data) {
    return JSON.stringify({timestamp: get_utc_time(), type, data}, null, 2) + '\
';
}


async function writeToLog(filePath, logJson, isPlayerLog = false, playerName = null) {
    ensureDir(path.dirname(filePath));
    try {
        await fs.promises.appendFile(filePath, logJson);
    } catch (err) {
        console.error(`写入日志失败: ${filePath}, 错误: ${err}`);
    }
}


// Player Statistics
const playerStats = {};

function updatePlayerStats(playerName, logType, data) {
    if (!playerStats[playerName]) {
        playerStats[playerName] = {
            dimensionChanges: 0,
            kills: 0,
            deaths: 0,
            containerOperations: 0,
            lastUpdate: get_utc_time(),
            lastPosition: null,
            containerAccesses: []
        };
    }

    switch (logType) {
        case "dimension":
            playerStats[playerName].dimensionChanges++;
            break;
        case "kill":
            playerStats[playerName].kills++;
            break;
        case "death":
            playerStats[playerName].deaths++;
            break;
        case "chest":
            playerStats[playerName].containerOperations++;
            const location = extractCoordinates(data.text);
            if (location) {
                playerStats[playerName].containerAccesses.push({
                    time: get_utc_time(),
                    position: location,
                    action: data.action
                });
                if (playerStats[playerName].containerAccesses.length > 100) {
                    playerStats[playerName].containerAccesses.shift();
                }
            }
            break;
    }

    playerStats[playerName].lastUpdate = get_utc_time();

    const statsPath = `./Log/players/${playerName}/stats.json`;
    ensureDir(path.dirname(statsPath));
    fs.writeFileSync(statsPath, JSON.stringify(playerStats[playerName], null, 2));
}

//Improved Coordinate Extraction (Handles more variations)
function extractCoordinates(text) {
    const regex = /(?:at|位置|坐标)\s*\(\s*(-?\d+\.?\d*),\s*(-?\d+\.?\d*),\s*(-?\d+\.?\d*)\s*\)|minecraft:\w+\s+(\d+):(-?\d+\.?\d*),(-?\d+\.?\d*),(-?\d+\.?\d*)/i;
    const match = text.match(regex);

    if (match) {
        const x = parseFloat(match[1] || match[5]);
        const y = parseFloat(match[2] || match[6]);
        const z = parseFloat(match[3] || match[7]);
        const dimension = match[4] ? parseInt(match[4]) : null;
        return { dimension, x: x.toFixed(1), y: y.toFixed(1), z: z.toFixed(1) };
    }
    return null;
}

// Container operation handling (modified)
function handleContainerOperation(playerName, data, dateStr) {
    const chestLogPath = `./Log/${dateStr}/Chest.log`;
    const isOpen = data.action === "open";
    const containerType = data.text.includes("Chest") ? "箱子" : "容器";
    const positionStr = data.position || "未知位置";
    const items = data.items || [];

    const detailedLogEntry = createLogJson("containerOperation", {
        playerName,
        action: isOpen ? "打开" : "关闭",
        containerType,
        position: positionStr,
        items,
        details: data // Include the original 'data' object for detailed information
    });

    writeToLog(chestLogPath, detailedLogEntry);
    if (playerName) {
        const playerChestLogPath = `./Log/${dateStr}/players/${playerName}/chest.log`;
        writeToLog(playerChestLogPath, detailedLogEntry, true, playerName);
    }
    updatePlayerStats(playerName, "chest", data);
    updateCumulativeStats("chest");
    if (config.debugMode) {
        console.log('\x1b[36m%s\x1b[0m', `容器操作: ${detailedLogEntry}`);
    }
    return data;
}



// Chat API push function
function pushChatToApi(payload, redirectCount = 0) {
    const MAX_REDIRECTS = 5;
    let data = JSON.stringify({
        ...payload,
        apiSecret: config.apiSecret,
        timestamp: get_utc_time()
    });

    const url = new URL(config.chatApiUrl);
    const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + url.search,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length,
            'Authorization': `Bearer ${config.apiSecret}`,
            'User-Agent': `USFLog-Plus/${config.version}`
        }
    };

    const requestModule = url.protocol === 'https:' ? https : http;

    const req = requestModule.request(options, (res) => {
        let responseData = '';
        res.on('data', (chunk) => {
            responseData += chunk;
        });
        res.on('end', () => {
            if (res.statusCode === 301 || res.statusCode === 302) {
                if (redirectCount >= MAX_REDIRECTS) {
                    console.error('达到最大重定向次数限制');
                    return;
                }
                const redirectUrl = res.headers.location;
                if (redirectUrl) {
                    console.log(`重定向到: ${redirectUrl}`);
                    config.chatApiUrl = redirectUrl;
                    pushChatToApi(payload, redirectCount + 1);
                }
                return;
            }
            if (res.statusCode !== 200) {
                console.error(`聊天API请求失败，状态码: ${res.statusCode}: ${responseData}`);
            } else if (config.debugMode) {
                console.log(`聊天API响应: ${responseData}`);
            }
        });
    });

    req.on('error', (e) => {
        console.error(`推送聊天信息失败: ${e.message}`);
        if (config.debugMode) {
            console.error('详细错误信息:', e);
        }
    });

    req.write(data);
    req.end();
}

// HTTP server creation function
function createHttpServer() {
    return http.createServer(async (req, res) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end("usf");

        let data;
        try {
            data = JSON.parse(req.headers.usf);
            data.text = decodeURIComponent(data.text);
            data.path = decodeURIComponent(data.path);
        } catch (error) {
            logError(error, req.headers.usf);
            console.error("Invalid JSON received:", error);
            return;
        }

        if (typeof data === "object") {
            const playerName = getPlayerNameFromPath(data.path);
            const dateStr = get_date();

            try {
                switch (data.type) {
                    case "log":
                        if (data.path.includes("Chat")) {
                            const chatLogPath = `./Log/${dateStr}/Chat.log`;
                            const chatLogJson = createLogJson("chatMessage", { playerName, message: data.text });
                            writeToLog(chatLogPath, chatLogJson);
                            if (config.showChatInConsole) {
                                console.log('\x1b[34m%s\x1b[0m', `[${get_shanghai_time()}] 聊天信息: ${data.text}`);
                            }
                            if (config.chatApiEnabled) {
                                const chatPayload = {
                                    messageType: "public",
                                    sender: playerName,
                                    content: data.text,
                                    recipientId: "all",
                                    pw: config.apiSecret
                                };
                                pushChatToApi(chatPayload);
                            }
                            updateCumulativeStats("chat");
                        } else if (data.text.includes("Close") || data.text.includes("Open")) {
                            const containerData = { ...data, items: parseContainerContent(data.text), action: data.text.includes("Open") ? "open" : "close", position: extractCoordinates(data.text) };
                            handleContainerOperation(playerName, containerData, dateStr);
                        } else {
                            if (playerName) {
                                const baseDir = `./Log/${dateStr}/players/${playerName}`;
                                const logType = identifyLogType(data.text);
                                let finalLogType = logType;
                                if (["Location", "In Land", "Edit Sign", "TP"].some(keyword => data.text.includes(keyword))) {
                                    finalLogType = "location";
                                }
                                const logPath = path.join(baseDir, `${finalLogType}.log`);
                                const logEntry = createLogJson(finalLogType, { playerName, message: data.text, coordinates: extractCoordinates(data.text) });
                                writeToLog(logPath, logEntry, true, playerName);
                                updatePlayerStats(playerName, logType, data);
                                updateCumulativeStats(logType, playerName);
                                if (logType === "connection") {
                                    if (data.text.startsWith("Join At")) {
                                        console.log('\x1b[32m%s\x1b[0m', `[${get_shanghai_time()}] 玩家 ${playerName} 加入了游戏`);
                                    } else if (data.text === "Leave") {
                                        console.log('\x1b[31m%s\x1b[0m', `[${get_shanghai_time()}] 玩家 ${playerName} 离开了游戏`);
                                    }
                                }
                            }
                        }
                        break;
                    case "print":
                        log(data.text);
                        break;
                    case "info":
                        if (playerName) {
                            const baseDir = `./Log/${dateStr}/players/${playerName}`;
                            const logPath = path.join(baseDir, `info.log`);
                            writeToLog(logPath, createLogJson("info", data.info), true, playerName);
                        }
                        break;
                }
            } catch (error) {
                logError(error, data);
                console.error("An error occurred during processing:", error);
            }
        }
    });
}


// Parse container content (improved)
function parseContainerContent(text) {
    const contentMatch = text.match(/Content: \[(.*?)\]/);
    if (contentMatch) {
        return contentMatch[1].split(',').map(item => {
            const [count, name] = item.trim().split('x').map(s => s.trim());
            return {count: parseInt(count, 10) || 1, name};
        });
    }
    return [];
}


// Log Type Identification
function identifyLogType(text) {
    const logTypes = {
        "connection": ["Join At", "Leave"],
        "dimension": ["Dimension Change:"],
        "interact": ["Interact Block"],
        "chest": ["Open ", "Close:", "Close : No Data"],
        "kill": ["Kill "],
        "death": ["Killed"],
        "break": ["Break "],
        "place": ["Place "],
        "location": ["Location", "In Land", "Edit Sign", "TP"],
        "gamemode": ["GameMode"],
        "sign": ["Sign Change"]
    };

    for (const [type, keywords] of Object.entries(logTypes)) {
        if (keywords.some(keyword => text.includes(keyword))) {
            return type;
        }
    }
    return "unknown";
}


// Player name from path
function getPlayerNameFromPath(filePath) {
    const matches = filePath.match(/Players\/([^\/]+)/);
    return matches ? matches[1] : null;
}

// Error handling and logging to Log/error.log
function logError(error, originalData) {
    const errorLogPath = './Log/error.log';
    ensureDir(path.dirname(errorLogPath));
    const errorData = {
        timestamp: get_utc_time(),
        error: error.stack || error.message,
        originalData: originalData || 'N/A'
    };
    const errorJson = JSON.stringify(errorData, null, 2) + '\
';
    try {
        fs.appendFileSync(errorLogPath, errorJson);
    } catch (err) {
        console.error("Failed to write to error.log:", err);
    }
}

// Server startup function
function startServers() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.on('line', (text) => {
        if (text === "stop") {
            log("退出日志程序！");
            process.exit();
        } else if (text === "gzlog") {
            log("立刻发起日志压缩...");
            cleanupAndCompressLogs(true);
        }
    });

    const connectionCounts = {};
    const connectionTimestamps = {};
    const lastBlockedLogTime = {};

    function checkAndLogConnection(clientAddress) {
        const currentTime = Date.now();
        const logFilePath = './Log/link.log';
        if (!connectionCounts[clientAddress]) {
            connectionCounts[clientAddress] = 0;
            connectionTimestamps[clientAddress] = [];
        }
        connectionCounts[clientAddress]++;
        connectionTimestamps[clientAddress].push(currentTime);
        connectionTimestamps[clientAddress] = connectionTimestamps[clientAddress].filter(timestamp => currentTime - timestamp <= 180000);

        if (connectionCounts[clientAddress] > config.maxConnectionsPerIP) {
            if (config.showConnectionInfo) {
                const lastLogTime = lastBlockedLogTime[clientAddress] || 0;
                if (currentTime - lastLogTime > 180000) {
                    console.log('\x1b[33m%s\x1b[0m', `由于 ${clientAddress} 发起连接次数超过 ${config.maxConnectionsPerIP} 次已暂时屏蔽显示`);
                    lastBlockedLogTime[clientAddress] = currentTime;
                }
            }
        } else {
            if (config.showConnectionInfo) {
                console.log('\x1b[32m%s\x1b[0m', `客户端 ${clientAddress} 连接于 ${get_shanghai_time()}`);
            }
        }

        writeToLog(logFilePath, createLogJson("connection", {clientAddress}));
    }


    const httpServer = createHttpServer();
    httpServer.on('connection', (socket) => {
        const clientAddress = socket.remoteAddress;
        const connectionTime = get_shanghai_time();
        if (config.useWhitelist && !config.whitelist.includes(clientAddress)) {
            console.log('\x1b[31m%s\x1b[0m', `客户端 ${clientAddress} 被禁止连接于 ${connectionTime}`);
            writeToLog('./Log/link.log', createLogJson("blockedConnection", {clientAddress}));
            socket.destroy();
        } else {
            if (config.antiSpamEnable) {
                checkAndLogConnection(clientAddress);
            } else {
                if (config.showConnectionInfo) {
                    console.log('\x1b[32m%s\x1b[0m', `客户端 ${clientAddress} 连接于 ${connectionTime}`);
                }
                writeToLog('./Log/link.log', createLogJson("connection", {clientAddress}));
            }
        }
    });

    httpServer.listen(config.port, config.openIP, () => {
        const startTime = process.hrtime();
        console.log('\x1b[33m%s\x1b[0m', 'USF Log Plus');
        console.log('\x1b[33m%s\x1b[0m', `版本号: ${config.version}`);
        console.log('\x1b[33m%s\x1b[0m', `启动时间: ${get_shanghai_time()}`);
        console.log('\x1b[33m%s\x1b[0m', `上次启动时间: ${config.lastStartupTime}`);
        console.log('\x1b[33m%s\x1b[0m', `上次启动用户: ${config.lastStartupUser}`);
        console.log('\x1b[33m%s\x1b[0m', `主程序开放IP和端口: ${config.openIP}:${config.port}`);
        const elapsedTime = process.hrtime(startTime);
        console.log('\x1b[33m%s\x1b[0m', `启动耗时: ${elapsedTime[0] * 1000 + elapsedTime[1] / 1e6} ms`);
        log("USF Log Plus 主程序启动完毕！");

        config.lastStartupTime = get_shanghai_time();
        config.lastStartupUser = process.env.USER || process.env.USERNAME || '未知用户';
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
        if (config.debugMode) {
            console.log('\x1b[36m%s\x1b[0m', `配置项目状态: ${JSON.stringify(config, null, 2)}`);
        }
        loadCumulativeStats();
    });

    if (config.chatApiEnabled) {
        const chatApiServer = http.createServer((req, res) => {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({status: "running", version: config.version, timestamp: get_utc_time()}));
        });
        chatApiServer.listen(config.chatApiPort, config.chatApiIP, () => {
            console.log('\x1b[33m%s\x1b[0m', `聊天API服务器启动在: ${config.chatApiIP}:${config.chatApiPort}`);
        });
    }

    setInterval(() => {
        cleanupAndCompressLogs();
    }, config.logCleanupInterval);
}

// Log cleanup and compression function
function cleanupAndCompressLogs(manualTrigger = false) {
    const logDir = './Log';
    const retentionDate = new Date(Date.now() - config.logRetentionDays * 86400000);
    const currentDate = new Date().toISOString().slice(0, 10);

    function deleteOldLogs(dir) {
        const files = fs.readdirSync(dir);
        let totalFiles = files.length;
        let processedFiles = 0;

        files.forEach(file => {
            const filePath = path.join(dir, file);
            const stats = fs.statSync(filePath);

            if (stats.isDirectory()) {
                const folderDate = file.replace(/\./g, '-');
                if (folderDate !== currentDate) {
                    deleteOldLogs(filePath);
                }
            } else {
                const fileDate = stats.mtime.toISOString().slice(0, 10);
                processedFiles++;
                if (stats.mtime < retentionDate) {
                    fs.unlinkSync(filePath);
                    console.log(`删除旧日志文件: ${filePath}`);
                } else if (config.logCompression && !file.endsWith('.gz') && fileDate !== currentDate) {
                    const gzip = zlib.createGzip();
                    const input = fs.createReadStream(filePath);
                    const output = fs.createWriteStream(filePath + '.gz');
                    input.pipe(gzip).pipe(output);
                    output.on('finish', () => {
                        fs.unlinkSync(filePath);
                        console.log(`压缩并删除原日志文件: ${filePath}`);
                        if (manualTrigger) {
                            const progress = Math.round((processedFiles / totalFiles) * 100);
                            console.log(`压缩进度: ${progress}%`);
                        }
                    });
                }
            }
        });
    }
    deleteOldLogs(logDir);
    if (manualTrigger) {
        log("日志压缩完成！");
    }
}


//Improved Error Handling in various sections

process.on('uncaughtException', (err) => {
    logError(err, 'Uncaught Exception');
    console.error('未捕获的异常:', err);
    log(`发生未捕获的异常: ${err.message}`);
    if (config.debugMode) {
        console.error('详细错误信息:', err);
    }
});

process.on('unhandledRejection', (reason, promise) => {
    logError(reason, 'Unhandled Rejection');
    console.error('未处理的Promise拒绝:', reason);
    log(`发生未处理的Promise拒绝: ${reason}`);
    if (config.debugMode) {
        console.error('详细错误信息:', reason);
    }
});


// Start servers
startServers();