const readline = require('readline');
const fs = require("fs");
const process = require("process");
const http = require('http');
const path = require('path');
const zlib = require('zlib');

// 配置
const defaultConfig = {
    port: 31145, //主程序端口
    chatApiPort: 31146, // 聊天API端口
    openIP: "0.0.0.0", //主程序监听IP
    chatApiIP: "0.0.0.0", // chatapi监听IP可设可不设
    maxConnectionsPerIP: 10, //鸡肋的防刷屏，开了后也不会影响连接记录日志的生成
    showConnectionInfo: true, //是否在控制台显示连接信息
    useWhitelist: true, //是否开启USF行为包连接IP白名单
    whitelist: ["127.0.0.1"],//IP白名单，可设置多个，一行一个，单个IP加上""号
    antiSpamEnable: true,//是否开启antiSpamEnable功能（实验性功能）
    showChatInConsole: true,//是否显示ChatInConsole在控制台
    debugMode: false, //debug开关（不要开，概率会出事）
    logBufferSize: 5 * 5, // 缓冲区大小（字节）
    logCleanupInterval: 86400000, // 日志清理间隔（毫秒）
    logRetentionDays: 7,  // 日志保留天数
    logCompression: true,  // 启用日志压缩
    chatApiEnabled: true, // 是否启用聊天API推送
    chatApiUrl: "http://example.com", // 聊天APIpush地址（仅支持HTTP，HTTPS请等待）
    pushPrivateChat: false, // 是否推送私聊信息
    apiSecret: "114511" // 聊天API密钥
};

let config = undefined;


const configPath = './LogServer.json';
if (fs.existsSync(configPath)) {
    const data = fs.readFileSync(configPath, 'utf-8');
    config = { ...defaultConfig, ...JSON.parse(data) };
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
} else {
    config = { ...defaultConfig };
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}


function get_time() {
    const date = new Date();
    return `[${padZero(date.getMonth() + 1)}.${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}:${padZero(date.getSeconds())}]`;
}

function padZero(num) {
    return num < 10 ? `0${num}` : num;
}

function get_shanghai_time() {
    const date = new Date();
    return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }).replace(/T/, ' ').slice(0, 19);
}

function get_utc_time() {
    const date = new Date();
    return date.toISOString().replace('T', ' ').slice(0, 19);
}

function log(text) {
    console.log(`${get_shanghai_time()} ${text}`);
}

function get_date() {
    const date = new Date();
    return `${date.getFullYear()}.${padZero(date.getMonth() + 1)}.${padZero(date.getDate())}`;
}

function ensureDir(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
}

function generateLogHeader(playerName) {
    return `ZUY-USFLog-Plus————${get_utc_time()}，${playerName}\n`;
}

function identifyLogType(text) {
    const logTypes = {
        "connection": ["Join At", "Leave"],
        "dimension": ["Dimension Change:"],
        "interact": ["Interact Block"],
        "chest": ["Open ", "Close:", "Close : No Data"],
        "kill": ["Kill "],
        "death": ["Killed"],
        "break": ["Break "],
        "place": ["Place "],
        "location": ["Location", "In Land", "Edit Sign", "TP"],
        "gamemode": ["GameMode"],
        "sign": ["Sign Change"]
    };

    for (const [type, keywords] of Object.entries(logTypes)) {
        if (keywords.some(keyword => text.includes(keyword))) {
            return type;
        }
    }

    return "unknown";
}

// 玩家统计结构
const playerStats = {};

// 更新玩家统计信息
function updatePlayerStats(playerName, logType, text) {
    if (!playerStats[playerName]) {
        playerStats[playerName] = {
            dimensionChanges: 0,
            kills: 0,
            deaths: 0,
            lastUpdate: get_utc_time()
        };
    }

    switch (logType) {
        case "dimension":
            playerStats[playerName].dimensionChanges++;
            break;
        case "kill":
            playerStats[playerName].kills++;
            break;
        case "death":
            playerStats[playerName].deaths++;
            break;
    }

    playerStats[playerName].lastUpdate = get_utc_time();

    // 保存统计信息到文件
    const statsPath = `./Log/players/${playerName}/stats.json`;
    ensureDir(path.dirname(statsPath));
    fs.writeFileSync(statsPath, JSON.stringify(playerStats[playerName], null, 2));
}

// 日志缓冲区
const logBuffer = {};

// 缓冲写日志函数
async function writeToLog(filePath, content, isPlayerLog = false, playerName = null) {
    ensureDir(path.dirname(filePath));

    // 初始化缓冲区如果不存在
    if (!logBuffer[filePath]) {
        logBuffer[filePath] = [];
    }

    // 添加内容到缓冲区
    logBuffer[filePath].push(`${get_shanghai_time()} ${content}\n`);

    // 如果缓冲区大小超过限制则刷新缓冲区
    if (logBuffer[filePath].join('').length >= config.logBufferSize) {
        await flushLogBuffer(filePath, isPlayerLog, playerName);
    }
}

// 刷新日志缓冲区到文件
async function flushLogBuffer(filePath, isPlayerLog = false, playerName = null) {
    if (logBuffer[filePath] && logBuffer[filePath].length > 0) {
       
        if (isPlayerLog && !fs.existsSync(filePath) && playerName) {
            await fs.promises.writeFile(filePath, generateLogHeader(playerName));
        }

        // 缓冲区内容写入
        await fs.promises.appendFile(filePath, logBuffer[filePath].join(''));
        logBuffer[filePath] = [];
    }
}

// 从路径中解析玩家name
function getPlayerNameFromPath(filePath) {
    const matches = filePath.match(/Players\/([^\/]+)/);
    return matches ? matches[1] : null;
}

// 启动服务器
function startServers() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.on('line', (text) => {
        if (text === "stop") {
            log("退出日志程序！");
            process.exit();
        } else if (text === "gzlog") {
            log("立刻发起日志压缩...");
            cleanupAndCompressLogs(true);
        }
    });

    const connectionCounts = {};
    const connectionTimestamps = {};
    const lastBlockedLogTime = {};

    function checkAndLogConnection(clientAddress) {
        const currentTime = Date.now();
        const logFilePath = './Log/link.log';

        if (!connectionCounts[clientAddress]) {
            connectionCounts[clientAddress] = 0;
            connectionTimestamps[clientAddress] = [];
        }

        connectionCounts[clientAddress]++;
        connectionTimestamps[clientAddress].push(currentTime);

        connectionTimestamps[clientAddress] = connectionTimestamps[clientAddress].filter(timestamp => currentTime - timestamp <= 180000);

        if (connectionCounts[clientAddress] > config.maxConnectionsPerIP) {
            if (config.showConnectionInfo) {
                const lastLogTime = lastBlockedLogTime[clientAddress] || 0;
                if (currentTime - lastLogTime > 180000) {
                    console.log('\x1b[33m%s\x1b[0m', `由于 ${clientAddress} 发起连接次数超过 用户设定次数 ${config.maxConnectionsPerIP} 次已为您暂时屏蔽显示`);
                    lastBlockedLogTime[clientAddress] = currentTime;
                }
            }
        } else {
            if (config.showConnectionInfo) {
                console.log('\x1b[32m%s\x1b[0m', `客户端 ${clientAddress} 连接于 ${get_shanghai_time()}`);
            }
        }

        fs.appendFileSync(logFilePath, `${get_shanghai_time()} 客户端 ${clientAddress} 连接\n`);
    }

    // HTTP服务器用于USF连接
    const frontServer = http.createServer(async function (req, res) {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end("usf");

        let data = req.headers.usf;
        try {
            data = JSON.parse(data);
        } catch (err) {
            return;
        }

        if (typeof data === "object") {
            data.text = decodeURI(data.text);
            data.path = decodeURI(data.path);

            const playerName = getPlayerNameFromPath(data.path);
            const dateStr = get_date();

            switch (data.type) {
                case "log":
                    if (data.path.includes("Chat")) {
                        const chatLogPath = `./Log/${dateStr}/Chat.log`;
                        // 修复删除重复的console.log用于聊天消息
                        await writeToLog(chatLogPath, data.text);
                        if (config.showChatInConsole) {
                            console.log('\x1b[34m%s\x1b[0m', `聊天信息: ${data.text}`);
                        }
                       
                        if (config.chatApiEnabled) {
                            const messageType = data.text.includes("私聊") ? "private" : "public";
                            const recipientId = messageType === "private" ? data.text.split('>>')[0].split('[')[2].trim() : "all";
                            const chatPayload = {
                                messageType,
                                sender: playerName,
                                timestamp: get_utc_time(),
                                content: data.text.split('>>')[1].trim(),
                                recipientId,
                                pw: config.apiSecret
                            };
                            pushChatToApi(chatPayload);
                        }
                        return;
                    }

                    if (data.text.includes("Close") || data.text.includes("Open")) {
                        const chestLogPath = `./Log/${dateStr}/Chest.log`;
                        await writeToLog(chestLogPath, data.text);
                        return;
                    }

                    if (playerName) {
                        const baseDir = `./Log/${dateStr}/players/${playerName}`;
                        const logType = identifyLogType(data.text);

                        let finalLogType = logType;
                        if (["Location", "In Land", "Edit Sign", "TP"].some(keyword => data.text.includes(keyword))) {
                            finalLogType = "location";
                        }

                        const logPath = path.join(baseDir, `${finalLogType}.log`);

                        updatePlayerStats(playerName, logType, data.text);

                        if (logType === "connection") {
                            if (data.text.startsWith("Join At")) {
                                log(`玩家 ${playerName} 加入了游戏`);
                            } else if (data.text === "Leave") {
                                log(`玩家 ${playerName} 离开了游戏`);
                            }
                        }

                        await writeToLog(logPath, data.text, true, playerName);
                    }
                    break;

                case "print":
                    log(data.text);
                    break;

                case "info":
                    if (playerName) {
                        const baseDir = `./Log/${dateStr}/players/${playerName}`;
                        const logPath = path.join(baseDir, `info.log`);
                        await writeToLog(logPath, JSON.stringify(data.info, null, 2), true, playerName);
                    }
                    break;
            }
        }
    });

    frontServer.listen(config.port, config.openIP, () => {
        const startTime = process.hrtime();
        console.log('\x1b[33m%s\x1b[0m', 'USF Log Plus');
        console.log('\x1b[33m%s\x1b[0m', '版本号: 1.0.0OSA');
        console.log('\x1b[33m%s\x1b[0m', `启动时间: ${get_shanghai_time()}`);
        console.log('\x1b[33m%s\x1b[0m', `主程序开放IP和端口: ${config.openIP}:${config.port}`);
        const elapsedTime = process.hrtime(startTime);
        console.log('\x1b[33m%s\x1b[0m', `启动耗时: ${elapsedTime[0] * 1000 + elapsedTime[1] / 1e6} ms`);
        log("usflog plus 主程序启动完毕！");
        if (config.debugMode) {
            console.log('\x1b[36m%s\x1b[0m', `配置项目状态: ${JSON.stringify(config, null, 2)}`);
        }
    });

    frontServer.on('connection', (socket) => {
        const clientAddress = socket.remoteAddress;
        const connectionTime = get_shanghai_time();

        if (config.useWhitelist && !config.whitelist.includes(clientAddress)) {
            console.log('\x1b[31m%s\x1b[0m', `客户端 ${clientAddress} 被禁止连接于 ${connectionTime}`);
            fs.appendFileSync('./Log/link.log', `${connectionTime} 客户端 ${clientAddress} 被禁止连接\n`);
            socket.destroy();
        } else {
            if (config.antiSpamEnable) {
                checkAndLogConnection(clientAddress);
            } else {
                if (config.showConnectionInfo) {
                    console.log('\x1b[32m%s\x1b[0m', `客户端 ${clientAddress} 连接于 ${connectionTime}`);
                }
                fs.appendFileSync('./Log/link.log', `${connectionTime} 客户端 ${clientAddress} 连接\n`);
            }
        }
    });

    // 定期清理和压缩日志
    setInterval(() => {
        cleanupAndCompressLogs();
    }, config.logCleanupInterval);

    // 启动聊天API服务器
    if (config.chatApiEnabled) {
        startChatApiServer();
    }
}

// 日志清理和压缩函数
function cleanupAndCompressLogs(manualTrigger = false) {
    const logDir = './Log';
    const retentionDate = new Date(Date.now() - config.logRetentionDays * 86400000);
    const currentDate = new Date().toISOString().slice(0, 10);

    function deleteOldLogs(dir) {
        const files = fs.readdirSync(dir);
        let totalFiles = files.length;
        let processedFiles = 0;

        files.forEach(file => {
            const filePath = path.join(dir, file);
            const stats = fs.statSync(filePath);
            if (stats.isDirectory()) {
                const folderDate = file.replace(/\./g, '-');
                if (folderDate !== currentDate) {
                    deleteOldLogs(filePath);
                }
            } else {
                const fileDate = stats.mtime.toISOString().slice(0, 10);
                processedFiles++;
                if (stats.mtime < retentionDate) {
                    fs.unlinkSync(filePath);
                    console.log(`删除旧日志文件: ${filePath}`);
                } else if (config.logCompression && !file.endsWith('.gz') && fileDate !== currentDate) {
                    // 压缩日志文件
                    const gzip = zlib.createGzip();
                    const input = fs.createReadStream(filePath);
                    const output = fs.createWriteStream(filePath + '.gz');
                    input.pipe(gzip).pipe(output);
                    output.on('finish', () => {
                        fs.unlinkSync(filePath);
                        console.log(`压缩并删除原日志文件: ${filePath}`);
                        if (manualTrigger) {
                            const progress = Math.round((processedFiles / totalFiles) * 100);
                            console.log(`压缩进度: ${progress}%`);
                        }
                    });
                }
            }
        });
    }

    // 仅压缩日期命名的目录中的日志
    deleteOldLogs(logDir);

    if (manualTrigger) {
        log("日志压缩完成！");
    }
}

// 推送聊天信息到API
function pushChatToApi(payload) {
    const data = JSON.stringify(payload);

    const url = new URL(config.chatApiUrl);
    const options = {
        hostname: url.hostname,
        port: url.port,
        path: url.pathname,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    };

    const req = http.request(options, (res) => {
        res.on('data', (d) => {
            process.stdout.write(d);
        });
    });

    req.on('error', (e) => {
        console.error(`推送聊天信息失败: ${e.message}`);
    });

    req.write(data);
    req.end();
}

// 启动聊天API服务器
function startChatApiServer() {
    const chatApiServer = http.createServer((req, res) => {
        // 聊天API服务器的请求处理逻辑
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end("Chat API Server is running");
    });

    chatApiServer.listen(config.chatApiPort, config.chatApiIP, () => {
        console.log('\x1b[33m%s\x1b[0m', `聊天API服务器启动在: ${config.chatApiIP}:${config.chatApiPort}`);
    });
}

// 启动服务器
startServers();